
import createApp from './app'
import './style.css'

document.addEventListener("DOMContentLoaded",()=>{
  createApp()
})


